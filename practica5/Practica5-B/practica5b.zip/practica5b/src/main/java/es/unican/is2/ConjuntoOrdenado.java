package es.unican.is2;

import java.util.ArrayList;
import java.util.List;

import es.unican.is2.adt.IConjuntoOrdenado;
/**
 * Clase que implementa el ADT ListaOrdenada
 */
public class ConjuntoOrdenado<E extends Comparable<E>> implements IConjuntoOrdenado<E> {

	private List<E> lista = new ArrayList<E>();

	public E get(int indice) {
		return lista.get(indice);
	}

	public boolean add(E elemento) {
		int indice = 0;
		if (elemento==null)
			throw new NullPointerException();
		
		// DEPURACIÓN DE CÓDIGO, tras ejecutar caja negra. Si ya existe, devolvemos false y no lo añadimos 
       	if (lista.contains(elemento)) {
            return false;
        }
		
		// Cambiamos el menor que por mayor que para que la lista se ordene de manera natural (de menor a mayor)
		if (lista.size() != 0) {
			while (indice < lista.size() && elemento.compareTo(lista.get(indice)) > 0) {
				indice++;
			}
		}
		lista.add(indice, elemento);
		return true;
	}

	public E remove(int indice) {
		E borrado = lista.remove(indice);
		return borrado;
	}

	public int size() {
		return lista.size();
	}

	public void clear() {
		lista.clear();
	}

}